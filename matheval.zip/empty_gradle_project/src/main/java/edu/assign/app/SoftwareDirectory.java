package edu.assign.app;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class SoftwareDirectory implements FileComponent{
    private final File directory;
    private final Map<String, SoftwareFile> files;
    private final Map<String, SoftwareDirectory> subdirectories;


    public SoftwareDirectory(File directory) throws IOException {
        this.directory = directory;
        this.files = new HashMap<>();
        this.subdirectories = new HashMap<>();
        loadFiles(directory);
    }
    public String getName(){
        return directory.getName();
    }

    private void loadFiles(File directory) throws IOException {
        File[] filesArray = directory.listFiles();
        if (filesArray == null) {

        }
        for (File file : filesArray) {
            if (file.isDirectory()) {
                SoftwareDirectory subdirectory = new SoftwareDirectory(file);
                subdirectories.put(file.getName(), subdirectory);
            } else {
                SoftwareFile softwareFile = new SoftwareFile(file);
                files.put(file.getName(), softwareFile);
            }
        }
    }






    @Override
    public int countMatchingLines(String pattern, boolean isRegex) {
        int count = 0;
        for (SoftwareFile file : files.values()) {
            count += file.countMatchingLines(pattern, isRegex);
        }
        for (SoftwareDirectory subdirectory : subdirectories.values()) {
            count += subdirectory.countMatchingLines(pattern, isRegex);
        }
        return count;
    }


    public File getDirectory() {
        return directory;
    }

    public Map<String, SoftwareFile> getFiles() {
        return files;
    }

    public Map<String, SoftwareDirectory> getSubdirectories() {
        return subdirectories;
    }
}

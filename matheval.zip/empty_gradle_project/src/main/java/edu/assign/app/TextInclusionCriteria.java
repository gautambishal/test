package edu.assign.app;

public class TextInclusionCriteria implements Criteria {
    private final String textToMatch;

    public TextInclusionCriteria(String textToMatch) {
        this.textToMatch = textToMatch;
    }

    @Override
    public boolean matches(String line) {
        return line.contains(textToMatch);
    }
}

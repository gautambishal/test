package edu.assign.app;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class SoftwareFile implements FileComponent {
    private final String name;
    private final String content;

    public SoftwareFile(String name, String content) {
        this.name = name;
        this.content = content;
    }

    public SoftwareFile(File file) {
        this.name = file.getName();
        this.content = "";
    }

    public String getName() {
        return name;
    }

    public String getContent() {
        return content;
    }

    public void printContents() {
        System.out.println(content);
    }

    @Override
    public int countMatchingLines(String pattern, boolean isRegex) {
        String[] lines = content.split("\n");
        int count = 0;
        for (String line : lines) {
            if (lineMatchesCriteria(line, pattern, isRegex)) {
                count++;
            }
        }
        return count;
    }

    public List<Integer> getMatchingLineNumbers(String pattern, boolean isRegex) {
        String[] lines = content.split("\n");
        List<Integer> matchingLineNumbers = new ArrayList<>();
        for (int i = 0; i < lines.length; i++) {
            if (lineMatchesCriteria(lines[i], pattern, isRegex)) {
                matchingLineNumbers.add(i+1);
            }
        }
        return matchingLineNumbers;
    }

    public String getLine(int lineNumber) {
        String[] lines = content.split("\n");
        if (lineNumber <= 0 || lineNumber > lines.length) {
            throw new IllegalArgumentException("Invalid line number");
        }
        return lines[lineNumber-1];
    }

    public void printMatchingLines(String pattern, boolean isRegex) {
        String[] lines = content.split("\n");
        for (int i = 0; i < lines.length; i++) {
            if (lineMatchesCriteria(lines[i], pattern, isRegex)) {
                System.out.println(name + ":" + (i+1) + ":" + lines[i]);
            }
        }
    }

    private boolean lineMatchesCriteria(String line, String pattern, boolean isRegex) {
        if (isRegex) {
            return line.matches(pattern);
        } else {
            return line.contains(pattern);
        }
    }
}

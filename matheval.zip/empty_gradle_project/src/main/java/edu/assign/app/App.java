package edu.assign.app;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class App {
    private static final Logger LOGGER = Logger.getLogger(App.class.getName());

    private Map<String, List<String>> filesByDir = new HashMap<>();
    private Map<String, Integer> linesByFile = new HashMap<>();
    private Map<String, String> contentsByFile = new HashMap<>();
    private static String currentDir;
    private String pattern;
    private boolean isRegex;
    private String outputFormat;

    public static void main(String[] args) {
        if(args.length<1){
            currentDir = Paths.get("").toAbsolutePath().toString();
        }else{
            currentDir= args[0];
        }
        LOGGER.log(Level.INFO,"current Dir {} ",currentDir);
        App app = new App();
        app.run(currentDir);
    }
    public void run(String rootDirName) {
        File rootDir = new File(rootDirName);
        System.out.println(rootDir.getName());
        readFiles(rootDir);
        try {
            showMenu();
        } catch(IOException e) {
            System.out.println(e.getMessage());
        }
    }

    private void readFiles(File dir) {
        for (File file : dir.listFiles()) {
            if (file.isDirectory()) {
                filesByDir.put(file.getName(), new ArrayList<>());
                readFiles(file);
            } else {
                try {
                    String content = new String(Files.readAllBytes(file.toPath()));
                    String[] lines = content.split("\\r?\\n");
                    if (filesByDir.get(dir.getName())!=null) {
                        filesByDir.get(dir.getName()).add(file.getName());

                        for(String line : lines) {
                            if(!linesByFile.containsKey(file.getName())) {
                                linesByFile.put(file.getName(), 0);
                            }
                            if(contentsByFile.get(file.getName())!=null) {
                                contentsByFile.put(file.getName(),contentsByFile.get(file.getName()).concat(line));
                            }else{
                                contentsByFile.put(file.getName(),line);
                            }
                            linesByFile.put(file.getName(), linesByFile.get(file.getName()) + 1);
                        }
                    }
                } catch (IOException e) {
                    // handle exception
                    LOGGER.log(Level.SEVERE,"got io exception with error message");
                    LOGGER.log(Level.SEVERE,"Error with message {}",e.getMessage());
                }
            }
        }
    }

    private void showMenu() throws IOException {
        Scanner scanner = new Scanner(System.in).useDelimiter("\n");
        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Set Criteria");
            System.out.println("2. Set Output Format");
            System.out.println("3. Report");
            System.out.println("4. Quit");
            String input = scanner.next();
            switch (input) {
                case "1":
                    setCriteria(scanner);
                    break;
                case "2":
                    setOutputFormat(scanner);
                    break;
                case "3":
                    report();
                    break;
                case "4":
                    scanner.close();
                    exit();
                    break;
                default:
                    LOGGER.severe("Invalid input, please try again.");
                    break;
            }
        }
    }

    private void exit() {
        return;
    }

    private void setCriteria(Scanner scanner) {
        scanner.nextLine();
        System.out.println("Enter search pattern:");
        pattern = scanner.nextLine();
        System.out.println("Use regex? (y/n)");
        scanner.nextLine(); //to avoid \n input from previous one
        String flag = scanner.nextLine();
        isRegex = flag.equalsIgnoreCase("y");
    }

    private void setOutputFormat(Scanner scanner) {
        System.out.println("Choose output format (count/show):");
        scanner.nextLine();
        outputFormat = scanner.nextLine();
    }

    private void report() throws IOException {
        int totalCount = 0;
        for (Map.Entry<String, List<String>> entry : filesByDir.entrySet()) {
            System.out.println("directory: "+entry.getKey());
           SoftwareDirectory directory = new SoftwareDirectory(new File(entry.getKey()));
            for (String filename : entry.getValue()) {
                SoftwareFile file = new SoftwareFile(filename, contentsByFile.get(filename));
                int count = file.countMatchingLines(pattern, isRegex);
                totalCount += count;
                if (count > 0 && outputFormat.equalsIgnoreCase("show")) {
                    List<Integer> matchingLineNumbers = file.getMatchingLineNumbers(pattern, isRegex);
                    for (int lineNumber : matchingLineNumbers) {
                        System.out.println(directory.getName() + "/" + file.getName() + ":" + lineNumber + ":" + file.getLine(lineNumber));
                    }
                }
            }
        }
        if (outputFormat.equalsIgnoreCase("count")) {
            LOGGER.log(Level.INFO,"Total matching lines: {}" , totalCount);
        }
    }
}

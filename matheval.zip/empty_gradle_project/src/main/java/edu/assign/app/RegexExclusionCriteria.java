package edu.assign.app;

import java.util.regex.Pattern;

public class RegexExclusionCriteria implements Criteria {
    private final Pattern pattern;

    public RegexExclusionCriteria(String regex) {
        this.pattern = Pattern.compile(regex);
    }

    @Override
    public boolean matches(String line) {
        return !pattern.matcher(line).find();
    }
}

package edu.assign.app;

public interface FileComponent {
    int countMatchingLines(String pattern, boolean isRegex);
}

package edu.assign.app;

public interface Criteria {
    boolean matches(String line);
}
